from project.elf import Elf


class MuseElf(Elf):

    def __init__(self, name, level):
        super(MuseElf, self).__init__(name, level)
