from project.knight import Knight


class DarkKnight(Knight):

    def __init__(self, name, level):
        super(DarkKnight, self).__init__(name, level)
        